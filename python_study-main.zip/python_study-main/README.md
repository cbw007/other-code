<p align="center">
  <a href="https://mehoon.com">
    <img src="https://blog.mehoon.com/wp-content/uploads/2021/06/cropped-avatar.jpg" width="130" />
  </a>
  <br />
  <b>云淡风轻</b>
  <p align="center">Python 小项目</p>
  <p align="center">学习、分享</p>
  
  <p align="center">
  <a href="https://github.com/haohaizhi/haohaizhi.github.io/blob/main/assets/qq.jpg">
  <img src="https://img.shields.io/badge/Talk-QQ-brightgreen.svg?style=popout-square" alt="QQ"></a>
  <a href="https://github.com/haohaizhi/python_study/stargazers">
  <img src="https://img.shields.io/github/stars/haohaizhi/python_study.svg?style=popout-square" alt="GitHub stars"></a>
  <a href="https://github.com/haohaizhi/python_study/issues">
  <img src="https://img.shields.io/github/issues/haohaizhi/python_study.svg?style=popout-square" alt="GitHub issues"></a>
</p>


<br />
<br />

# 汇总
|编号|链接|时间|
| :--: | :-- | :--: |
|1|[项目：前程无忧爬虫](https://github.com/haohaizhi/51job_spiders)|2020/09/05|
|2|[python图片转字符画](https://github.com/haohaizhi/python_study/tree/main/scripts/python%E5%9B%BE%E7%89%87%E8%BD%AC%E5%AD%97%E7%AC%A6%E7%94%BB)|2021/07/29|
|3|[python生成二维码](https://github.com/haohaizhi/python_study/tree/main/scripts/python%E7%94%9F%E6%88%90%E4%BA%8C%E7%BB%B4%E7%A0%81)|2021/07/29|
|4|[python小游戏2048](https://github.com/haohaizhi/python_study/tree/main/scripts/python%E5%B0%8F%E6%B8%B8%E6%88%8F2048)|2021/08/02|
|5|[python多人聊天室](https://github.com/haohaizhi/python_study/tree/main/scripts/python%E5%A4%9A%E4%BA%BA%E8%81%8A%E5%A4%A9%E5%AE%A4)|2021/09/22|
|6|[python简单web服务器](https://github.com/haohaizhi/python_study/tree/main/scripts/python%E7%AE%80%E5%8D%95web%E6%9C%8D%E5%8A%A1%E5%99%A8)|2021/09/22|
|7|[项目：高德地图-58同城租房](https://github.com/haohaizhi/58house_spiders)|2021/09/30|
|8|[python图像隐写术](https://github.com/haohaizhi/python_study/tree/main/scripts/python%E5%9B%BE%E5%83%8F%E9%9A%90%E5%86%99%E6%9C%AF)|2021/10/09|
