# python脚本-简单web服务器

![](images/1.png)

![](images/2.png)



