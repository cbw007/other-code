# python脚本-将图片转换成字符画

- 图片

![](images/1.png)

- 字符画

![](images/2.png)

