# python脚本-图像隐写术

- 图片

![](master.png)

- 加密

![](images/1.png)

- 解密

![](images/2.png)

```python
#注意，因为中文字符占两个字节，所以加密过程中每个字符转换成二进制时都存放成16位
```